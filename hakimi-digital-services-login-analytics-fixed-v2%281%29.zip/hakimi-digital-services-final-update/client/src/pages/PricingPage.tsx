import { ArrowRight, ArrowLeft, Check, Info, Tag } from 'lucide-react';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { BUSINESS } from '@/lib/constants';
import { type Route } from '@/lib/router';

type PriceTier = {
  name: string;
  price: string;
  description: string;
  features: string[];
  popular?: boolean;
};

const PRICE_TIERS: PriceTier[] = [
  {
    name: 'Basic Registration',
    price: '₹499',
    description: 'For simple registrations and documentation needs.',
    features: [
      'Udyam Registration',
      'PAN/TAN Services',
      'Digital Signature',
      'Application processing',
      'Email support',
    ],
  },
  {
    name: 'Standard License',
    price: '₹999',
    description: 'For licenses and registrations requiring more documentation.',
    features: [
      'GST Registration',
      'FSSAI License',
      'Shop Act License',
      'IEC Registration',
      'Priority processing',
      'WhatsApp + Call support',
      'Document verification',
    ],
    popular: true,
  },
  {
    name: 'Premium Compliance',
    price: '₹2,499',
    description: 'For complex registrations and full compliance packages.',
    features: [
      'Company Registration',
      'Trademark Registration',
      'All Standard features included',
      'Dedicated expert assistance',
      'Expedited processing',
      'Full compliance consultation',
      'Priority support',
    ],
  },
];

const NOTE =
  'Prices are indicative service charges for documentation assistance only. Government fees, if applicable, are separate and vary by service. Final pricing depends on your specific requirements. Contact us for a detailed quote.';

export default function PricingPage({ navigate }: { navigate: (r: Route) => void }) {
  const [services, setServices] = useState<any[]>([]);
  const [offers, setOffers] = useState<any[]>([]);
  useEffect(() => {
    Promise.all([
      supabase.from('service_catalog').select('*').eq('is_active', true).order('sort_order'),
      supabase.from('offers').select('*').eq('is_active', true).order('sort_order').limit(6),
    ]).then(([serviceRes, offerRes]) => {
      if (!serviceRes.error && serviceRes.data?.length) setServices(serviceRes.data);
      if (!offerRes.error) setOffers(offerRes.data || []);
    });
  }, []);

  return (
    <div className="min-h-screen bg-navy-50 pt-20 lg:pt-24">
      <div className="container-x py-12 lg:py-16">
        <button
          onClick={() => navigate('home')}
          className="mb-6 flex items-center gap-2 text-sm font-medium text-navy-500 transition-colors hover:text-navy-900"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </button>

        <div className="text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-gold-50 px-4 py-1.5">
            <span className="text-xs font-semibold tracking-wide text-gold-700">PRICING</span>
          </div>
          <h1 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-navy-900 sm:text-4xl lg:text-5xl">
            Simple, Transparent Pricing
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-base text-navy-500">
            Fair pricing for professional documentation services. No hidden charges, no surprises.
          </p>
        </div>

        {services.length > 0 && (
          <div className="mt-12">
            <div className="mb-6 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-gold-700">Live Service Pricing</div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {services.filter((service:any) => !offers.some((o:any) => o.is_active && ((o.service_id && o.service_id === service.id) || (o.service_name && String(o.service_name).toLowerCase() === String(service.name).toLowerCase())))).map((service:any) => <div key={service.id} className="rounded-2xl border border-navy-100 bg-white p-5 shadow-sm"><div className="flex items-start justify-between gap-3"><div><h3 className="font-display font-bold text-navy-900">{service.name}</h3><p className="mt-1 text-sm text-navy-500">{service.description}</p></div>{service.badge && <span className="rounded-full bg-gold-100 px-2.5 py-1 text-xs font-bold text-gold-800">{service.badge}</span>}</div>{service.price != null && <div className="mt-4 flex items-baseline gap-2"><strong className="text-2xl text-navy-900">₹{Number(service.price).toLocaleString('en-IN')}</strong>{service.old_price != null && <span className="text-sm text-navy-400 line-through">₹{Number(service.old_price).toLocaleString('en-IN')}</span>}</div>}<button onClick={() => { sessionStorage.setItem('hds_apply_service', service.name); navigate('apply'); }} className="mt-4 flex items-center gap-2 rounded-lg bg-navy-900 px-4 py-2 text-sm font-semibold text-white">Apply Now <ArrowRight className="h-4 w-4" /></button></div>)}
            </div>
          </div>
        )}

        {offers.length > 0 && <div className="mt-10 rounded-2xl border border-gold-200 bg-gold-50 p-6"><div className="flex items-center gap-2 font-bold text-gold-800"><Tag className="h-4 w-4" /> Active Offers</div><div className="mt-4 grid gap-3 md:grid-cols-2 lg:grid-cols-3">{offers.map((o:any)=><div key={o.id} className="rounded-xl bg-white p-4"><div className="font-bold text-navy-900">{o.title}</div><div className="mt-1 text-sm text-navy-500">{o.description}</div>{o.discount_text && <div className="mt-2 text-sm font-bold text-gold-700">{o.discount_text}</div>}</div>)}</div></div>}

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {PRICE_TIERS.map((tier) => (
            <div
              key={tier.name}
              className={`relative rounded-3xl border bg-white p-8 shadow-sm transition-all hover:shadow-xl ${
                tier.popular
                  ? 'border-gold-400 shadow-lg ring-2 ring-gold-400/20'
                  : 'border-navy-100'
              }`}
            >
              {tier.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gold-500 px-4 py-1 text-xs font-bold uppercase tracking-wider text-navy-900">
                  Most Popular
                </div>
              )}
              <h3 className="font-display text-lg font-bold text-navy-900">{tier.name}</h3>
              <p className="mt-2 text-sm text-navy-500">{tier.description}</p>
              <div className="mt-4">
                <span className="font-display text-4xl font-extrabold text-navy-900">
                  {tier.price}
                </span>
                <span className="text-sm text-navy-400"> onwards</span>
              </div>
              <button
                onClick={() => { sessionStorage.setItem('hds_apply_service', service.name); navigate('apply'); }}
                className={`mt-6 flex w-full items-center justify-center gap-2 rounded-lg px-5 py-3 text-sm font-semibold transition-all active:scale-95 ${
                  tier.popular
                    ? 'bg-gold-500 text-navy-900 hover:bg-gold-400 hover:shadow-lg hover:shadow-gold-500/30'
                    : 'bg-navy-900 text-white hover:bg-navy-800'
                }`}
              >
                Apply Now
                <ArrowRight className="h-4 w-4" />
              </button>
              <ul className="mt-6 space-y-3">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2.5">
                    <div className="mt-0.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-gold-100">
                      <Check className="h-3 w-3 text-gold-700" strokeWidth={3} />
                    </div>
                    <span className="text-sm text-navy-700">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Note */}
        <div className="mt-8 flex items-start gap-3 rounded-2xl border border-blue-200 bg-blue-50 p-5">
          <Info className="mt-0.5 h-5 w-5 flex-shrink-0 text-blue-600" />
          <p className="text-sm leading-relaxed text-blue-800">{NOTE}</p>
        </div>

        {/* CTA */}
        <div className="mt-12 rounded-3xl bg-navy-900 p-8 text-center lg:p-12">
          <h3 className="font-display text-2xl font-bold text-white sm:text-3xl">
            Need a custom quote?
          </h3>
          <p className="mx-auto mt-3 max-w-xl text-base text-navy-200">
            Contact us with your specific requirements and we'll provide a tailored pricing plan.
          </p>
          <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
            <a
              href={BUSINESS.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 rounded-lg bg-[#25D366] px-7 py-3.5 text-sm font-semibold text-white transition-all hover:bg-[#1eb855] active:scale-95"
            >
              Chat on WhatsApp
            </a>
            <button
              onClick={() => navigate('contact')}
              className="flex items-center justify-center gap-2 rounded-lg border border-white/20 bg-white/5 px-7 py-3.5 text-sm font-semibold text-white transition-all hover:border-white/40 active:scale-95"
            >
              Contact Us
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
