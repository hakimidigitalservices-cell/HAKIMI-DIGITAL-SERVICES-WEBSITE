import { useState, type FormEvent } from 'react';
import { ArrowRight, Eye, EyeOff, LockKeyhole, Mail, UserPlus, UserRound } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { type Route } from '@/lib/router';

export default function CustomerLoginPage({ navigate }: { navigate: (r: Route) => void }) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setError(null); setMessage(null);
    try {
      if (mode === 'signup') {
        if (!name.trim()) throw new Error('Please enter your full name.');
        if (!/^\d{10}$/.test(mobile.trim())) throw new Error('Mobile number must be 10 digits.');
        const { data, error: signUpError } = await supabase.auth.signUp({
          email: email.trim(), password,
          options: { data: { full_name: name.trim(), mobile_number: mobile.trim() } },
        });
        if (signUpError) throw signUpError;
        if (data.session) {
          const afterLogin = sessionStorage.getItem('hds_after_login');
          sessionStorage.removeItem('hds_after_login');
          navigate(afterLogin === 'apply' ? 'apply' : 'dashboard');
        }
        else setMessage('Account created. Please check your email if verification is required, then login.');
      } else {
        const { error: loginError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (loginError) throw loginError;
        const afterLogin = sessionStorage.getItem('hds_after_login');
        sessionStorage.removeItem('hds_after_login');
        navigate(afterLogin === 'apply' ? 'apply' : 'dashboard');
      }
    } catch (err) { setError(err instanceof Error ? err.message : 'Something went wrong.'); }
    finally { setBusy(false); }
  };

  return <div className="min-h-[80vh] bg-navy-50 pt-20 lg:pt-24">
    <div className="container-x py-10 lg:py-16">
      <div className="mx-auto grid max-w-5xl overflow-hidden rounded-3xl border border-navy-100 bg-white shadow-xl lg:grid-cols-2">
        <div className="bg-navy-900 p-8 text-white lg:p-12">
          <div className="mb-8 inline-flex rounded-2xl bg-white/10 p-3"><LockKeyhole className="h-7 w-7 text-gold-400" /></div>
          <h1 className="font-display text-3xl font-extrabold lg:text-4xl">Your HDS Customer Portal</h1>
          <p className="mt-4 leading-7 text-navy-100">Track applications, upload documents, download certificates and contact our team from one secure dashboard.</p>
          <div className="mt-8 space-y-3 text-sm text-navy-100"><div>✓ Application status in one place</div><div>✓ Document & certificate access</div><div>✓ Direct WhatsApp support</div><div>✓ Support requests without calling</div></div>
        </div>
        <div className="p-7 lg:p-10">
          <div className="mb-4 rounded-2xl border border-gold-200 bg-gold-50 p-4 text-sm text-navy-700"><div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-full bg-navy-900 text-gold-400"><UserRound className="h-5 w-5" /></div><div><b className="text-navy-900">Login required before applying</b><div className="text-xs text-navy-500">Your name, mobile and email can be pre-filled automatically on the application form.</div></div></div></div>
          <div className="mb-7 flex rounded-xl bg-navy-50 p-1"><button onClick={() => setMode('login')} className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-semibold ${mode === 'login' ? 'bg-white text-navy-900 shadow-sm' : 'text-navy-500'}`}>Login</button><button onClick={() => setMode('signup')} className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-semibold ${mode === 'signup' ? 'bg-white text-navy-900 shadow-sm' : 'text-navy-500'}`}>Create Account</button></div>
          <form onSubmit={submit} className="space-y-4">
            {mode === 'signup' && <><label className="block text-sm font-semibold text-navy-800">Full Name<input value={name} onChange={e=>setName(e.target.value)} className="input-field mt-1.5" placeholder="Your full name" /></label><label className="block text-sm font-semibold text-navy-800">Mobile Number<input value={mobile} onChange={e=>setMobile(e.target.value.replace(/\D/g,'').slice(0,10))} className="input-field mt-1.5" placeholder="10-digit mobile" /></label></>}
            <label className="block text-sm font-semibold text-navy-800"><span className="flex items-center gap-2"><Mail className="h-4 w-4"/>Email</span><input type="email" value={email} onChange={e=>setEmail(e.target.value)} className="input-field mt-1.5" placeholder="you@example.com" required /></label>
            <label className="block text-sm font-semibold text-navy-800"><span className="flex items-center gap-2"><LockKeyhole className="h-4 w-4"/>Password</span><span className="relative block"><input type={showPassword?'text':'password'} value={password} onChange={e=>setPassword(e.target.value)} className="input-field mt-1.5 pr-11" placeholder="••••••••" minLength={6} required/><button type="button" onClick={()=>setShowPassword(!showPassword)} className="absolute right-3 top-3.5 text-navy-400">{showPassword?<EyeOff className="h-4 w-4"/>:<Eye className="h-4 w-4"/>}</button></span></label>
            {error && <div className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}
            {message && <div className="rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700">{message}</div>}
            <button disabled={busy} className="flex w-full items-center justify-center gap-2 rounded-xl bg-gold-500 px-5 py-3.5 font-bold text-navy-900 transition hover:bg-gold-400 disabled:opacity-60">{busy?'Please wait...':mode==='login'?'Login to Dashboard':'Create Customer Account'} {mode==='login'?<ArrowRight className="h-4 w-4"/>:<UserPlus className="h-4 w-4"/>}</button>
          </form>
          <p className="mt-5 text-center text-xs text-navy-400">By continuing, you agree to our website terms and privacy policy.</p>
        </div>
      </div>
    </div>
  </div>;
}
