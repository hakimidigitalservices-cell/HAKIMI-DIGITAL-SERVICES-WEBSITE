import { useState, useEffect } from 'react';
import { Phone, Menu, X, ArrowRight, ShieldCheck, UserRound } from 'lucide-react';
import { BUSINESS } from '@/lib/constants';
import { type Route, navigateTo } from '@/lib/router';

const NAV_ITEMS: { label: string; route: Route }[] = [
  { label: 'Home', route: 'home' },
  { label: 'About Us', route: 'about' },
  { label: 'Services', route: 'services' },
  { label: 'Pricing', route: 'pricing' },
  { label: 'How It Works', route: 'how-it-works' },
  { label: 'Track Application', route: 'track' },
  { label: 'Contact Us', route: 'contact' },
];

export default function Header({ route, navigate }: { route: Route; navigate: (r: Route) => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [route]);

  const handleNav = (r: Route) => {
    navigate(r);
    setMobileOpen(false);
  };

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        scrolled
          ? 'bg-white/95 shadow-md shadow-navy-900/5 backdrop-blur-md'
          : 'bg-white/80 backdrop-blur-sm'
      }`}
    >
      <div className="container-x">
        <div className="flex h-16 items-center justify-between lg:h-20">
          {/* Logo */}
          <button
            onClick={() => handleNav('home')}
            className="flex items-center gap-2.5 transition-transform hover:scale-[1.02]"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-navy-900 lg:h-12 lg:w-12">
              <ShieldCheck className="h-5 w-5 text-gold-500 lg:h-6 lg:w-6" strokeWidth={2.5} />
            </div>
            <div className="text-left leading-none">
              <div className="font-display text-base font-extrabold tracking-tight text-navy-900 lg:text-lg">
                HAKIMI
              </div>
              <div className="text-[10px] font-semibold tracking-[0.15em] text-gold-600 lg:text-xs">
                DIGITAL SERVICES
              </div>
            </div>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden items-center gap-6 lg:flex">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.route}
                onClick={() => handleNav(item.route)}
                className={`nav-link ${route === item.route ? 'active' : ''}`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Desktop CTA */}
          <div className="hidden items-center gap-3 lg:flex">
            <button onClick={() => handleNav('customer-login')} className="flex items-center gap-2 rounded-lg border border-navy-200 px-4 py-2.5 text-sm font-semibold text-navy-800 transition-all hover:border-gold-400 hover:text-gold-600"><UserRound className="h-4 w-4"/> Customer Login</button>
            <a
              href={`tel:${BUSINESS.phone}`}
              className="flex items-center gap-2 rounded-lg border border-navy-200 px-4 py-2.5 text-sm font-semibold text-navy-800 transition-all hover:border-gold-400 hover:text-gold-600"
            >
              <Phone className="h-4 w-4" />
              Call {BUSINESS.phone}
            </a>
            <button
              onClick={() => handleNav('apply')}
              className="flex items-center gap-2 rounded-lg bg-gold-500 px-5 py-2.5 text-sm font-semibold text-navy-900 transition-all hover:bg-gold-400 hover:shadow-lg hover:shadow-gold-500/30"
            >
              Apply Now
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="flex h-10 w-10 items-center justify-center rounded-lg text-navy-800 lg:hidden"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="border-t border-navy-100 bg-white lg:hidden">
          <nav className="container-x flex flex-col py-4">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.route}
                onClick={() => handleNav(item.route)}
                className={`flex items-center justify-between rounded-lg px-4 py-3 text-left text-sm font-medium transition-colors ${
                  route === item.route
                    ? 'bg-navy-50 text-navy-900'
                    : 'text-navy-600 hover:bg-navy-50'
                }`}
              >
                {item.label}
                <ArrowRight className="h-4 w-4 opacity-40" />
              </button>
            ))}
            <div className="mt-3 flex flex-col gap-2 px-4">
              <a
                href={`tel:${BUSINESS.phone}`}
                className="flex items-center justify-center gap-2 rounded-lg border border-navy-200 px-4 py-3 text-sm font-semibold text-navy-800"
              >
                <Phone className="h-4 w-4" />
                Call {BUSINESS.phone}
              </a>
              <button
                onClick={() => handleNav('customer-login')}
                className="flex items-center justify-center gap-2 rounded-lg border border-navy-200 px-4 py-3 text-sm font-semibold text-navy-800"
              >
                <UserRound className="h-4 w-4" />
                Customer Login
              </button>
              <button
                onClick={() => handleNav('apply')}
                className="flex items-center justify-center gap-2 rounded-lg bg-gold-500 px-4 py-3 text-sm font-semibold text-navy-900"
              >
                Apply Now
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
